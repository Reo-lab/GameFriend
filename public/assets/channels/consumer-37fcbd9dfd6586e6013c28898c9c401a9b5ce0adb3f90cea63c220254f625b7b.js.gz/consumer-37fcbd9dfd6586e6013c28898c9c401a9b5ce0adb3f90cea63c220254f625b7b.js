import { createConsumer } from "@rails/actioncable"

const consumer = createConsumer(); 

export default createConsumer();
